package com.example.tinderella.chat;

public class SendNotification {
  public SendNotification(String text, String s, String notification, String activityToBeOpened, String matchesActivity) {
  }
}
