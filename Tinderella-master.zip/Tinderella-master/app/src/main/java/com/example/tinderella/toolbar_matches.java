package com.example.tinderella;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class toolbar_matches extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toolbar_matches);
    }
}